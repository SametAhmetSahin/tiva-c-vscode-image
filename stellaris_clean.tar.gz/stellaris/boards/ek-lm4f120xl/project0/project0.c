//*****************************************************************************
//
// project0.c - Example to demonstrate minimal StellarisWare setup
//
// Copyright (c) 2012 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 9453 of the EK-LM4F120XL Firmware Package.
//
//*****************************************************************************

#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

#include "inc/lm4f120h5qr.h"

int main(void) {
    volatile unsigned long delay;


    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOF;


    GPIO_PORTF_DIR_R |= 0b00000100;
    GPIO_PORTF_DEN_R |= 0b00000100;

    while(1) {
        GPIO_PORTF_DATA_R |= 0b00000100;
        for(delay = 0; delay < 400000; delay++)
            /* bos dongu ile bekle */;


        GPIO_PORTF_DATA_R &= ~(0b00000100);
        for(delay = 0; delay < 400000; delay++)
            /* bos dongu ile bekle */;
    }
}
